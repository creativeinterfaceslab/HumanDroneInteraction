package com.example.notificationtracker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.notificationtracker.ui.theme.NotificationTrackerTheme
import java.io.File

class MainActivity : ComponentActivity() {
    companion object {
        var uiState = mutableStateOf("Notifications received: 0")

        fun updateUI() {
            uiState.value = "Notifications received: ${NotificationService.notificationCount}"
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkNotificationListenerPermission()
        setContent {
            NotificationTrackerTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NotificationCountScreen()
                }
            }
        }
    }

    private fun saveCountToFile() {
        val fileName = "NotificationCount.txt"
        val data = uiState.value
        File(filesDir, fileName).writeText(data)
    }

    private fun checkNotificationListenerPermission() {
        val enabledNotificationListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        val packageName = packageName

        if (enabledNotificationListeners == null || !enabledNotificationListeners.contains(packageName)) {
            // Alert the user to enable the notification listener
            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            startActivity(intent)
        }
    }
}
@Composable
fun NotificationCountScreen() {
    val text by MainActivity.uiState

    Column(modifier = Modifier.fillMaxSize()) {
        Text(text = text)
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    NotificationTrackerTheme {
        NotificationCountScreen()
    }
}