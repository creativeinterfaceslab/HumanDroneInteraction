package com.example.notificationtracker

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log


class NotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        notificationCount++
        Log.d("NotificationService", "Notification received: $notificationCount")
        MainActivity.updateUI()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Optionally, handle notification removal here
    }

    companion object {
        var notificationCount = 0
    }
}